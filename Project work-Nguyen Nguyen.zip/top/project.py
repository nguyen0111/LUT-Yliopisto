from datetime import datetime

def read_vehicles(vehicle_file):
    vehicles_list = []
    file = open(vehicle_file, 'r')
    for line in file:
        parts = line.strip().split(',')
        vehicles_list.append({
            "plate": parts[0],
            "model": parts[1],
            "dailyrate": int(parts[2]),
            "features": parts[3:]
        })
    file.close()
    return vehicles_list

def read_customers(customer_file):
    customer_list = {}
    file = open(customer_file, 'r')
    for line in file:
        parts = line.strip().split(',')
        customer_list[parts[0]] = {
            "firstname": parts[1],
            "lastname": parts[2],
            "email": parts[3]
        }
    file.close()
    return customer_list

def read_rented_vehicles(rented_file):
    rentals = []
    file = open(rented_file, 'r')
    for line in file:
        parts = line.strip().split(',')
        rentals.append({
            "plate": parts[0],
            "birthdate": parts[1],
            "rental_start": parts[2]
        })
    file.close()
    return rentals

def validate_email(email):
    if "@" in email and "." in email:
        at_index = email.index("@")
        dot_index = email.rindex(".")
        if at_index > 0 and at_index + 1 < dot_index < len(email) - 1:
            return True
    return False

def validate_name(name):
    if len(name) > 0 and name[0].isupper():
        for char in name:
            if not char.isalpha():
                return False
        return True
    return False

def calculate_age(birthdate):
    today = datetime.today()
    birth_date = datetime.strptime(birthdate, '%d/%m/%Y')
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    return age

def list_available_cars():
    vehicles = read_vehicles("vehicles.txt")
    rented_vehicles = []

    for rental in read_rented_vehicles("rentedVehicles.txt"):
        rented_vehicles.append(rental["plate"])

    print("\nAvailable Cars:")
    for car in vehicles:
        if car["plate"] not in rented_vehicles:
            features = ""
            for feature in car["features"]:
                features += feature + ", "
            features = features[:-2]
            print(f"* Reg. nr: {car['plate']}, Model: {car['model']}, Price per day: {car['dailyrate']}")
            print(f"Properties: {features}")

def rent_a_car():
    plate = input("Enter car plate number: ")
    vehicles = read_vehicles("vehicles.txt")
    rentals = read_rented_vehicles("rentedVehicles.txt")

    found_vehicle = False
    for car in vehicles:
        if car["plate"] == plate:
            found_vehicle = True
            break

    if not found_vehicle:
        print("Car not found.")
        return

    for rental in rentals:
        if rental["plate"] == plate:
            print("Car is already rented.")
            return

    while True:
        birthdate = input("Enter customer birthdate (DD/MM/YYYY): ")
        try:
            age = calculate_age(birthdate)
            if age < 18:
                print("You must be at least 18 years old to rent a car.")
                return
            if age > 75:
                print("You are too old to rent a car.")
                return
        except ValueError:
            print("Invalid birthdate format. Please try again.")
            continue
        break

    customers = read_customers("customers.txt")
    if birthdate not in customers:
        while True:
            firstname = input("Enter first name: ")
            if not validate_name(firstname):
                print("Invalid first name. First name should start with a capital letter.")
                continue
            break

        while True:
            lastname = input("Enter last name: ")
            if not validate_name(lastname):
                print("Invalid last name. Last name should start with a capital letter.")
                continue
            break

        while True:
            email = input("Enter email: ")
            if not validate_email(email):
                print("Invalid email address. Please try again.")
                continue
            break

        file = open("customers.txt", 'a')
        file.write(f"{birthdate},{firstname},{lastname},{email}\n")
        file.close()


    # rental_start = input("Enter rental start time (DD/MM/YYYY HH:MM): ")
    # try:
    #     datetime.strptime(rental_start, '%d/%m/%Y %H:%M')
    # except ValueError:
    #     print("Invalid rental start time format.")
    #     return
    rental_start = datetime.today().strftime("%d/%m/%Y %H:%M")
    # print(rental_start.strftime("%m/%d/%Y %I:%M %p"))


    file = open("rentedVehicles.txt", 'a')
    file.write(f"{plate},{birthdate},{rental_start}\n")
    file.close()

    customers = read_customers("customers.txt")
    print(f"Hi! {customers[birthdate]['firstname']}, you have successfully rented car {plate}.")

def return_a_car():
    plate = input("Enter car plate number to return: ")
    vehicles = read_vehicles("vehicles.txt")
    rentals = read_rented_vehicles("rentedVehicles.txt")

    rental = None
    existed_car = False

    for c in vehicles:
        if c["plate"] == plate:
            existed_car = True
            break

    if not existed_car:
        print("Car not found.")
        return

    for r in rentals:
        if r["plate"] == plate:
            rental = r
            break

    if rental is None:
        print("Car not currently rented.")
        return

    daily_rate = 0
    for car in vehicles:
        if car["plate"] == plate:
            daily_rate = car["dailyrate"]
            break

    rental_start = datetime.strptime(rental["rental_start"], '%d/%m/%Y %H:%M')
    rental_end = datetime.now()
    rental_days = (rental_end - rental_start).days + 1
    rental_price = rental_days * daily_rate

    file = open("rentedVehicles.txt", 'w')
    for r in rentals:
        if r["plate"] != plate:
            file.write(f"{r['plate']},{r['birthdate']},{r['rental_start']}\n")
    file.close()

    file = open("transActions.txt", 'a')
    file.write(f"{plate},{rental['birthdate']},{rental['rental_start']},"
               f"{rental_end.strftime('%d/%m/%Y %H:%M')},{rental_days},{rental_price:.2f}\n")
    file.close()
    print(f"Car returned. Your rent lasted for {rental_days} and the total price is {rental_price:.2f}.")

def count_the_money():
    total_revenue = 0
    file = open("transActions.txt", 'r')
    for line in file:
        parts = line.strip().split(',')
        total_revenue += float(parts[5])
    file.close()
    print(f"Total money: {total_revenue:.2f}")

def main_menu():
    while True:
        print("\nMenu:")
        print("1. List available cars")
        print("2. Rent a car")
        print("3. Return a car")
        print("4. Count the money.")
        print("0. Exit")

        choice = input("Enter your choice: ")
        if choice == '1':
            list_available_cars()
        elif choice == '2':
            rent_a_car()
        elif choice == '3':
            return_a_car()
        elif choice == '4':
            count_the_money()
        elif choice == '0':
            print("Thanks. Bye.")
            break
        else:
            print("Invalid choice, please try again.")

main_menu()
